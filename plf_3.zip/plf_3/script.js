
    function submitForm(action) {
        var form = document.getElementById('baseform');
        form.action = action;
        form.submit();
    };